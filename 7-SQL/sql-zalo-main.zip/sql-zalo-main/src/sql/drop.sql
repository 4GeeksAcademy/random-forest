DROP TABLE book_authors;

DROP TABLE books;

DROP TABLE authors;

DROP TABLE publishers;